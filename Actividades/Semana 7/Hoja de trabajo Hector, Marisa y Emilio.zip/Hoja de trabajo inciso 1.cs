using System;

class Program
{
    static void Main() {
        //Hector Flores 1199923, Maria Isabel 1068823 Emilio Contreras 1246423
        int cont = 0;
        double ahorro = 0;
        double sumatoria = 0;
        
        for(int i=1;i<=12; i++){ 
            
        Console.WriteLine("Ingrese la cantidad que va a ahorrar");
        ahorro = Convert.ToDouble(Console.ReadLine());
        
        
        sumatoria = sumatoria + ahorro;
        cont++;
        
        Console.WriteLine("Lleva ahorrado en el mes  " + cont + ": " + sumatoria);
        
        
            }
            Console.WriteLine("El total ahorrado al año es: "  + sumatoria);
    }        
}
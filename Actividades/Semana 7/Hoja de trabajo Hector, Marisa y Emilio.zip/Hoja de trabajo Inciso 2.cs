using System;

class Program
{
    static void Main() {
         //Hector Flores 1199923, Maria Isabel 1068823 Emilio Contreras 1246423
        Console.WriteLine("Categoria 1 = venta > 1300, Categoria 2 = 300 < venta <= 1300, Categoria 3 = venta < 300");
        int cont1 = 0;
        int cont2 = 0;
        int cont3 = 0;
        double suma1 = 0;
        double suma2 = 0;
        double suma3 = 0;
        double b = 0;
        char respuesta = 's';

        do
        {
            Console.WriteLine("Ingrese el total de la venta");
            b = Convert.ToDouble(Console.ReadLine());

            if (b > 1300)
            {

                suma1 = suma1 + b;
                cont1++;

            }
            else if (b > 300 && b <= 1300)
            {

                suma2 = suma2 + b;
                cont2++;
            }
            else if (b <= 300)
            {

                suma3 = suma3 + b;
                cont3++;
            }


            Console.WriteLine("Desea seguir ingresando más ventas? s = si y n = no");
            respuesta = Convert.ToChar(Console.ReadLine());

        } while (respuesta == 's');



        Console.WriteLine("Se realizaron " + cont1 + " ventas de la categoria 1 y su sumatoria es: " + suma1);
        Console.WriteLine("Se realizaron " + cont2 + " ventas de la categoria 2 y su sumatoria es: " + suma2);
        Console.WriteLine("Se realizaron " + cont3 + " ventas de la categoria 3 y su sumatoria es: " + suma3);

        Console.WriteLine("En total se realizaron " + (cont1 + cont2 + cont3) + " ventas y su sumatoria total es: " + (suma1 + suma2 + suma3));
    }
    
}
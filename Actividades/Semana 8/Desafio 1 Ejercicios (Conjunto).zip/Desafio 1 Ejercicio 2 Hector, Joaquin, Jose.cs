﻿using System;

namespace Hoja_Trabajo_DESAFIO
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("EJERCICIO 2: ");
            //VARIABLES
            double valor, salario = 0;
            double horas;
            double SumSalario = 0;
            int empleados = 0;

            bool continuar = true;
            bool R_InValida = true;
            char respuesta;

            while(continuar == true)
            {
                //SOLICITAR DATOS
                Console.WriteLine("INGRESE LA PAGA DEL EMPLEADO (PAGO POR HORA): ");
                valor = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("INGRESE LAS HORAS TRABAJADAS SEMANALMENTE POR EL EMPLEADO: ");
                horas = Convert.ToDouble(Console.ReadLine());

                if(valor > 0 && horas > 0) //INGRESE NUMEROS POSITIVOS
                {
                    salario = valor * horas;

                    Console.WriteLine("EL SALARIO SEMANAL DEL EMPLEADO ES: Q" + salario);

                    SumSalario = SumSalario + salario;
                    empleados++;

                }
                else
                {
                    Console.WriteLine("ERROR: INGRESE DATOS VALIDOS (NUMEROS POSITIVOS)");
                }

                

                while (R_InValida == true)//PARA QUE INGRESE UN CHAR VALIDO
                {

                    Console.WriteLine("¿DESEA CONTINUAR? (Si = s / No = n)");
                    respuesta = Convert.ToChar(Console.ReadLine());

                    if (respuesta == 's')
                    {
                        continuar = true;
                        R_InValida = false;

                    }
                    else if (respuesta == 'n')
                    {
                        continuar = false;
                        R_InValida = false;
                    }
                    else
                    {
                        Console.WriteLine("EROR: INGRESE UNA RESPUESTA VALIDA");
                        R_InValida = true;
                    }
                }
                R_InValida = true;

            }//WHILE

            Console.WriteLine("EL NUMERO DE EMPLEADOS ES: " + empleados);
            Console.WriteLine("EL SALARIO DE TODOS LOS EMPLEADOS ES: Q" + SumSalario);
        }
    }
}

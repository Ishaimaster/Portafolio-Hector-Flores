﻿
Console.WriteLine("Trabajo caja registradora Joaquín Choc, Héctor Flores, José Valle");
double dinero = 0;
int billetes;
int monedas;
bool InValido = true;

while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q100");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 100);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
        InValido = true;
    }
}
InValido = true;

while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q50");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 50);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;


while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q20");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 20);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;


while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q10");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 10);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q5");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 5);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de billetes de Q1");
    billetes = Convert.ToInt32(Console.ReadLine());

    if (billetes >= 0)
    {
        dinero = dinero + (billetes * 1);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de Monedas de Q1");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 1);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de Monedas de c50");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 0.50);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de monedas de c25");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 0.25);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de monedas de c10");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 0.10);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de monedas de c5");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 0.05);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



while (InValido == true)
{
    Console.WriteLine("Ingresar la cantidad de monedas de c1");
    monedas = Convert.ToInt32(Console.ReadLine());

    if (monedas >= 0)
    {
        dinero = dinero + (monedas * 0.01);
        InValido = false;
    }
    else
    {
        Console.WriteLine("ERROR: INGRESÓ UNA CANTIDAD INVALIDA");
    }

}
InValido = true;



Console.WriteLine("EL VALOR TOTAL ES DE: Q" + dinero);


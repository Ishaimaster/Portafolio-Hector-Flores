﻿// See https://aka.ms/new-console-template for more information
// Hector Flores 1199923, Joaquin Choc 1280423, Jose Valle 1149123
int mes = 1;
double pisto = 10;
double total = 0;
double deuda = 10;
Console.WriteLine("EJERCICIO 1");
for (int i = 1; i <=20; i++)
{
    deuda = deuda * 2;



}


for (int i = 1; i <= 20; i++)
{  
    Console.WriteLine("Mes num. " + i);

    Console.WriteLine();

    Console.WriteLine("Abono: " + pisto);

    Console.WriteLine();

   
    total = total + pisto;

    pisto = pisto * 2;

    double tdeuda = deuda - pisto;

    Console.WriteLine("Total a pagar " + tdeuda);
   
    Console.WriteLine();
}

Console.WriteLine("Abono un total de: " + total);

//




